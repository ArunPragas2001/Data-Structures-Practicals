 class Stack{

char[]arr;
int top;

public Stack(int size)
{
    arr=new char[size];
    top=-1;
}

public void push(char c)
{
    arr[++top]=c;
}

public char pop()
{
    return arr[top--];
}

public boolean isEmpty()
{
    return top==-1;
}

 }


 public class Stack2022
 {
    public static boolean isBalanced(String exp)
    {
        Stack stack =new Stack(exp.length());

        for(int i=0; i<exp.length(); i++)
        {
            char ch=exp.charAt(i);

            if(ch=='(' || ch=='{' || ch=='[')
            {
                 stack.push(ch);

            }
            else if(ch==')' || ch=='}' || ch==']')
            {
                if(stack.isEmpty())
                {
                    return false;
                }
            
            char top=stack.pop();


            if((ch== ')' && top!= '(' ) || (ch== '}' && top!= '{'  ) || (ch== ']' && top!= '['))
            {
                return false;
            }

        }

    }

      return stack.isEmpty();
    }
    public static void main(String[]args)
    {
        String expression1="{[()]}";
        String expression2="[(])";


        if (isBalanced(expression1))
            System.out.println("expression1 has balanced brackets");
        else
            System.out.println("expression1 is not balanced");

        if (isBalanced(expression2))
            System.out.println("expression2 has balanced brackets");
        else
            System.out.println("expression2 is not balanced");




    }






 }
