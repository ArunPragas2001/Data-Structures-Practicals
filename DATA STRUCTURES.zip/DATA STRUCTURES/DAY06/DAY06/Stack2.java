class P{
 
  int num=100;


}

 class C extends P{

	int num=200;

	void 
	



}