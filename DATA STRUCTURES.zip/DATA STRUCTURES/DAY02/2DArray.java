//write a java programme to perform the following 2-Dimentional Array Operations
/*Print a 2D array values
Read a 2D array using keyboard input
Find the maximum value
Find the minimum value
Find the row sum
Find the column sum*/







class DArray{

	public static void main(String[]args){
		
		Scanner sc=new Scanner(System.in);
		
		int 2DA[2][2];
		
		for(i=0; i<2; i++){
			
			int num=sc.NextInt();
			num=2DA[i][2];
			
			
		}
		
		
		
			
	
	}
}