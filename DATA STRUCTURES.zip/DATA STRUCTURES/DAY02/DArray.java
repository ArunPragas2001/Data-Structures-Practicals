import java.util.*;

//write a java programme to perform the following 2-Dimentional Array Operations
/*Print a 2D array values
Read a 2D array using keyboard input
Find the maximum value
Find the minimum value
Find the row sum
Find the column sum*/







class DArray{

	public static void main(String[]args){
		
		Scanner sc=new Scanner(System.in);
		
	     int arr[][]=new int[3][3];
		
		for(int i=0; i<3; i++){
			
			
			System.out.println("Enter the number");
			int num=sc.nextInt();
			num=arr[i][3];
			
			
		}
	    for(int j=0; j<3; j++)
		{
			System.out.println("Enter the number");
			
			
			
		}
		
		
			
	
	}
}