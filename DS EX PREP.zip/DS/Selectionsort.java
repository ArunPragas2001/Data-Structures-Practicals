public  class Selectionsort {

    int[]arr;



    public static void selectionsort(int arr[])
    { 
        
        int n=arr.length;

        for(int i=0; i<n; i++ )
        {
            int minIndex=i;
            for(int j=i+1; j<n; j++)
            {
                if(arr[j]<arr[minIndex])
                {
                    minIndex=j;


                }

            }

            int temp=arr[i];
             arr[i]=arr[minIndex];
             arr[minIndex]=temp;



        }






    }

    public static void display(int arr[])
    {
      for(int item : arr)
        {
         System.out.print(item+", ");
    
        } 

        
    }

    public static void main(String[]args)
    {
         int[]arr ={5,0,12,-5,16,2,12,14};

         System.out.println("Array is");

        display(arr);
          
        System.out.println("After SelctionSort");

        selectionsort(arr);

        display(arr);





    }
    
}
